===========================================================================
  BmuS (BackMeUpScotty) - Docker Starter Kit
===========================================================================

Welcome to BmuS!
This package contains everything you need to run the BmuS backup 
tool in a Docker container on your NAS (Synology, QNAP, UGREEN) or 
Raspberry Pi.

BmuS is a powerful free backup program for the automated backup 
of files, directories, and MySQL databases from a Linux / Raspberry Pi 
system to a NAS or network drive or from a NAS to another NAS. 

It features encryption, deduplication, and much more.

You can find the complete documentation for BmuS here:
https://www.back-me-up-scotty.com

BmuS was developed with low-resource systems in mind, enabling 
single-board computers such as Raspberry Pi to run it efficiently.

One of the key features that has received special attention 
(or is it called “Love”?) is the dashboard. The pro version of the 
dashboard does not only provide simple status information, 
but also includes trend analyses (such as size growth, 
duration and more) and displays the backup history of the 
last 30 days.

This installation of BmuS includes the standard dashboard with essential 
metrics. If you like, you can upgrade to Dashboard Pro for $10/10EUR 
and support further development.

You can find more information about Dashboard Pro here:
https://www.back-me-up-scotty.com/docs/what-is-bmus/buy-pro-dashboard/

---------------------------------------------------------------------------
  PREREQUISITES
---------------------------------------------------------------------------
1. Docker
2. Docker Compose

(Most modern NAS systems, Linux and Raspberry Pi OS versions support 
this out of the box).

---------------------------------------------------------------------------
  QUICK START GUIDE
---------------------------------------------------------------------------

1. EXTRACT
   Unzip this folder to a directory on your system (e.g., /docker/bmus 
   or /home/pi/bmus).

2. CONFIGURE
   Go into the 'config' folder and edit the configuration files (see details below).
   
   IMPORTANT: You MUST edit 'bmus.conf', 'bmus_credentials', 'msmtp.conf' 
   (in case you want to have the report via email) before starting!

3. START
   Open a terminal, navigate to this folder, and run:
   
     sudo docker compose up -d

   Docker will automatically download the latest image and start the background service.
   
  Alternative: If you prefer GitHub Container Registry, use 
  image: ghcr.io/backmeupscotty/bmus:latest in the docker-compose.yml.

---------------------------------------------------------------------------
  CONFIGURATION FILES (in /config folder)
---------------------------------------------------------------------------

1. bmus.conf (Main Configuration)
   - Define your Backup Sources here.
   - Set your NAS IP and Share name for the destination.
   - Configure the Cron Schedule (Default: 03:00 AM daily).

   >>> IMPORTANT ABOUT PATHS <<<
   Since BmuS runs inside a container, it sees your host system mounted 
   under "/host_root". You MUST add this prefix to your source paths!
   
   Example:
   Real Path on Host:    /home/pi/documents
   Path in bmus.conf:    /host_root/home/pi/documents

2. bmus_credentials (Passwords)
   - Enter the Username/Password for your NAS (Backup Destination).
   - Enter MySQL credentials if you enabled Database backups.

3. msmtp.conf (Email Settings - Optional)
   - Configure your SMTP server here to receive backup reports.
   - NOTE: Do NOT use quotation marks (' or ") for the password field!
     Correct:   password MySecretPass123
     Incorrect: password 'MySecretPass123'

---------------------------------------------------------------------------
  ENCRYPTION (gocryptfs vs. GPG)
---------------------------------------------------------------------------

BmuS offers two types of encryption for different purposes:

1. FILE ENCRYPTION (Recommended for standard backups)
   For regular files and folders, BmuS uses 'gocryptfs'. This is fast and 
   standard practice.
   - To enable: Set ENCRYPTION=1 in 'bmus.conf'.
   - Create a file named 'bmus_gocryptfs' in the 'config' folder containing
     your password.
   - See bmus.conf -> ENCRYPTION_PASSWORD_FILE="/config/bmus_gocryptfs"

2. DATABASE ENCRYPTION (GPG)
   GPG is primarily intended for encrypting MySQL/MariaDB database dumps 
   (single files), as gocryptfs handles the general file storage.
   
   If you use GPG, you have two options:
   
   Option A: Simple Password (Symmetric)
   - Add your password to the 'bmus_encryption_pass' file (same as above).
   
   Option B: Key Pair (Asymmetric)
   - Create a folder named 'gnupg' inside the 'config' folder.
   - Copy your keyring files (pubring.kbx, trustdb.gpg) into 'config/gnupg'.
   - The container automatically fixes permissions on startup.
   
   If you use BmuS within a docker container, run: 
   docker exec -it bmus_backup gpg --homedir /config/gnupg --full-generate-key
   Output will be something like
   pub   rsa3072 2025-11-13 [SC]
   F8626AA681126A1857268C7B05F5A4D8EF68315A
   uid   John Doe <john@doe.com>
   GPG_RECIPIENT will be "john@doe.com"
   
---------------------------------------------------------------------------
  HOW TO RUN COMMANDS (RESTORE, LIST, ETC.)
---------------------------------------------------------------------------

To use commands like --restore or --list, you cannot run the script directly.
Instead, use the included helper script 'bmus' inside this folder.

   1. Make the helper script executable (first time only):
   chmod +x bmus

   2. Run your commands just like normally, but using ./bmus:

   List all backups:
   ./bmus --restore --list --source all

   Restore a specific backup:
   ./bmus --restore --date 2025-12-31-1400 --source /host_root/home/pi/data

   Trigger a manual backup:
   ./bmus

   Show help:
   ./bmus --help

---------------------------------------------------------------------------
  PRO FEATURES (Optional)
---------------------------------------------------------------------------

If you have purchased the BmuS Dashboard Pro:

1. Place the file 'bmus_dashboard_pro.sh' directly into the 'config' folder.
   (Do not rename the file).
   
2. Open bmus.conf

3. Change DASHBOARD_MODE="simple" to DASHBOARD_MODE="advanced" 

4. Change DASHBOARD_GENERATOR="$HOME_PI/bmus_dashboard.sh" to 
   DASHBOARD_GENERATOR="$HOME_PI/bmus_dashboard_pro.sh"

5. Restart the container to apply permissions:
   sudo docker compose restart bmus

6. The Pro Dashboard will now be generated automatically after every backup.

---------------------------------------------------------------------------
  USEFUL COMMANDS
---------------------------------------------------------------------------

Check the status / logs:
  sudo docker logs -f bmus_backup

Manually start a backup immediately (for testing):
  sudo docker exec -it -e CONFIG_FILE=/config/bmus.conf bmus_backup /app/bmus.sh

Update to the latest version:
  sudo docker compose pull
  sudo docker compose up -d

---------------------------------------------------------------------------
  TROUBLESHOOTING
---------------------------------------------------------------------------

- "Permission denied" / "Read-only file system":
  This is usually fixed by the container automatically. Ensure you are mapping 
  paths using the /host_root prefix as described above.

- Email authentication failed:
  Check msmtp.conf. Ensure you did not use quotes around your password.
  Restart the container after changing the config:
  sudo docker compose restart bmus

- Warning "Permissions 770":
  On some NAS systems, you might see a warning about file permissions in the log. 
  You can safely ignore this; the backup will run fine.

===========================================================================
  Project by BackMeUpScotty
===========================================================================